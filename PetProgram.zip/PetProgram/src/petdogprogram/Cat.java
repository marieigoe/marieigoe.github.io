/*
 * @author : Marie Igoe
 * @created : 02/05/2021
 */

package petdogprogram;

class Cat extends Pet {

    /**
     * class attributes
     */
    public int catSpaceNbr;
    public double catWeight;
    public boolean grooming;

    /**
     * Required constructor:
     */
    public Cat(String petType, String petName, int petAge, int daysStay, int catSpaceNbr, double catWeight, boolean grooming) 
        {
		super(petType, petName, petAge, daysStay);

        this.catSpaceNbr = catSpaceNbr;
        this.catWeight = catWeight;
        this.grooming = grooming;
    }

    public int getCatSpace() {
        return catSpaceNbr;
    }

    public void setCatSpaceNbr(int catSpaceNbr) {
        this.catSpaceNbr = catSpaceNbr;
    }

    public boolean getGrooming() {
        return grooming;
    }

    public void setGrooming(boolean grooming) {
        this.grooming = grooming;
    }

    public double getCatWeight() {
        return catWeight;
    }

    public void setCatWeight(double catWeight) {
        this.catWeight = catWeight;
    }

}
