/*
 * @author : Marie Igoe
 * @created : 02/05/2021
 */

package petdogprogram;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Program {

    private static List<Pet> pets;

    private static void menu() {
        System.out.println("Select an option...");
        System.out.println("1) Board pet");
        System.out.println("2) Groom pet");
        System.out.println("3) Train pet");
        System.out.println("4) List pets");
        System.out.println("5) Remove Pet");
        System.out.println("0) Exit.");

        System.out.print(": ");
        String choice = new Scanner(System.in).nextLine();
        if (choice.equals("1")) {
            boardPet();
        } else if (choice.equals("2")) {
            groomPet();
        } else if (choice.equals("3")) {
            trainPet();
        } else if (choice.equals("4")) {
            listPets();
        } else if (choice.equals("4")) {
            removePet();
        } else if (choice.equals("0")) {
            System.out.println("Thank you for visiting us. Bye!");
            System.exit(0);//Exit point
            return;
        } else {
            System.out.println("Wrong choice, try again!!");

        }
        menu(); //loop through till use exits the program
    }

    private static void boardPet() {
        int age, days, space;
        String name, type;
        double weight;
        boolean grooming;
        System.out.print("Enter the name of the pet: ");
        name = new Scanner(System.in).nextLine();
        System.out.print("Enter the type of the pet: ");
        type = new Scanner(System.in).nextLine().trim().toUpperCase();
        System.out.print("Enter the age of the pet: ");
        age = new Scanner(System.in).nextInt();
        System.out.print("Enter the number of days: ");
        days = new Scanner(System.in).nextInt();
        System.out.print("Enter the space to be used: ");
        space = new Scanner(System.in).nextInt();
        System.out.print("Enter the weight of the pet: ");
        weight = new Scanner(System.in).nextDouble();
        grooming = true;
        Pet pet = null;
        if (type.equals("DOG")) {
            pet = new Dog(type, name, age, days, space, weight, grooming);
        } else if (type.equals("CAT")) {
            pet = new Cat(type, name, age, days, space, weight, grooming);
        } else {
            System.out.println("We only offer Dogs and Cats services");
            return;
        }
        pet.setAmountDue(days * 50.00);
        pets.add(pet); // add to the list

    }

    private static void groomPet() {
        int age, days, space;
        String name, type;
        double weight;
        boolean grooming;
        System.out.print("Enter the name of the pet: ");
        name = new Scanner(System.in).nextLine();
        System.out.print("Enter the type of the pet: ");
        type = new Scanner(System.in).nextLine().trim().toUpperCase();
        System.out.print("Enter the age of the pet: ");
        age = new Scanner(System.in).nextInt();
        System.out.print("Enter the number of days: ");
        days = new Scanner(System.in).nextInt();
        System.out.print("Enter the space to be used: ");
        space = new Scanner(System.in).nextInt();
        System.out.print("Enter the weight of the pet: ");
        weight = new Scanner(System.in).nextDouble();
        grooming = false;
        Pet pet = null;
        if (type.equals("DOG")) {
            pet = new Dog(type, name, age, days, space, weight, grooming);
        } else if (type.equals("CAT")) {
            pet = new Cat(type, name, age, days, space, weight, grooming);
        } else {
            System.out.println("We only offer Dogs and Cats services");
            return;
        }
        pet.setAmountDue(30.00);
        pets.add(pet); //add it to the list
    }

    private static void trainPet() {
        int age, days = 1, space;
        String name, type;
        double weight;
        boolean grooming;
        System.out.print("Enter the name of the pet: ");
        name = new Scanner(System.in).nextLine();
        System.out.print("Enter the type of the pet: ");
        type = new Scanner(System.in).nextLine().trim().toUpperCase();
        System.out.print("Enter the age of the pet: ");
        age = new Scanner(System.in).nextInt();
        System.out.print("Enter the space to be used: ");
        space = new Scanner(System.in).nextInt();
        System.out.print("Enter the weight of the pet: ");
        weight = new Scanner(System.in).nextDouble();
        grooming = false;
        Pet pet = null;
        if (type.equals("DOG")) {
            pet = new Dog(type, name, age, days, space, weight, grooming);
        } else if (type.equals("CAT")) {
            pet = new Cat(type, name, age, days, space, weight, grooming);
        } else {
            System.out.println("We only offer Dogs and Cats services");
            return;
        }
        pet.setAmountDue(50.0d);
        pets.add(pet); //add it to the list
    }

    private static void listPets() {
        System.out.println("All Pets (" + pets.size() + ")");
        //summarize the dogs and the cats
        int dogs = 0, cats = 0;
        for (Pet p : pets) {
            if (Dog.class.isInstance(p)) {
                dogs++;
            } else if (Cat.class.isInstance(p)) {
                cats++;
            }
        }
        System.out.println("Cats (" + cats + ")");
        System.out.println("Dogs (" + dogs + ")");
    }

    private static void removePet() {
        System.out.println("Enter the name of the pet");
        String name = new Scanner(System.in).nextLine().toLowerCase();
        List<Pet> petsnew = new LinkedList<Pet>();// the new list to handle pets
        for (Pet p : pets) {
            if (!name.equals(p.getPetName())) {
                petsnew.add(p);//add all pets not matching the name
            } else {
                System.out.println("Removed the pet successfully!");
            }
        }
        pets = petsnew;
    }

    public static void main(String[] args) {
        pets = new LinkedList<Pet>();// initialize the list for storing pets
        menu();
    }
}
