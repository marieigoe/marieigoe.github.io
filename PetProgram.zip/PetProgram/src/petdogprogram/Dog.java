/*
 * @author : Marie Igoe
 * @created : 02/05/2021
 */

package petdogprogram;

class Dog extends Pet {

    /**
     * class attributes
     */
    public int dogSpaceNbr;
    public double dogWeight;
    public boolean grooming;

    /**
     * Required constructor:
     */
    public Dog(String petType, String petName, int petAge, int daysStay, int dogSpaceNbr, double dogWeight, boolean grooming) 
        {
		super(petType, petName, petAge, daysStay);

        this.dogSpaceNbr = dogSpaceNbr;
        this.dogWeight = dogWeight;
        this.grooming = grooming;
    }

    public int getDogSpace() {
        return dogSpaceNbr;
    }

    public void setDogSpaceNbr(int dogSpaceNbr) {
        this.dogSpaceNbr = dogSpaceNbr;
    }

    public boolean getGrooming() {
        return grooming;
    }

    public void setGrooming(boolean grooming) {
        this.grooming = grooming;
    }

    public double getDogWeight() {
        return dogWeight;
    }

    public void setDogWeight(double dogWeight) {
        this.dogWeight = dogWeight;
    }

}