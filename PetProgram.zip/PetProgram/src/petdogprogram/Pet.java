/*
 * @author : Marie Igoe
 * @created : 02/05/2021
 */


package petdogprogram;

public class Pet {
	
	private String petType;
	private String petName;
	private int petAge;
	private static int catSpace;
	private static int dogSpace;
	private int daysStay;
	private double amountDue;
        private boolean isIn;
	
	public Pet (String petType, String petName, int petAge, int daysStay) {
		setPetName(petName);
		setPetType(petType);
		setPetAge(petAge);
		setCatSpace(12);
		setDogSpace(30);
		setDaysStay(daysStay);
		isIn = false;
	}
	// Mutator and accessor
	
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public int getPetAge() {
		return petAge;
	}
	public void setPetAge(int petAge) {
		this.petAge = petAge;
	}
	public int getDogSpace() {
		return dogSpace;
	}
	public void setDogSpace(int dogSpace) {
		Pet.dogSpace= dogSpace;
	}
	public int getCatSpace() {
		return catSpace;
	}
	public void setCatSpace(int catSpace) {
		Pet.catSpace= catSpace;
	}
	public int getDaysStay() {
		return daysStay;
	}
	public void setDaysStay(int daysStay) {
		this.daysStay = daysStay;
	}
	public double getAmountDue() {
		return amountDue;
	}
	public void setAmountDue(double amountDue) {
		this.amountDue = amountDue;
	}
	
	// Method
	
	public void checkIn()
	{
            isIn=true;
	}
	public void checkOut()
	{
            isIn= false;
	}
	public Pet getPet()
	{
		return this;
	}
	public void creatPet()
	{
	}
	public void updatePet()
	{
	}
}